def hello_world():
    "Function that says hello."
    print("Hello, world!")

def hello():
    "Script to say hello"
    print("Hello from the other side!")

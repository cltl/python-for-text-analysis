# Creating a browser-based demo

See [../Examples/Flask-website](../Examples/Flask-website) for an example of how to make a browser-based demo.

# Using separate files

The notebook in this folder shows you how to separate your code into different files, and then import that code to use it in other scripts.

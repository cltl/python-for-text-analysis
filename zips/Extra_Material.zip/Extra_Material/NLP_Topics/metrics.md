# Metrics

This is a stub. Someday there will hopefully be more here.

* [Precision and Recall](https://en.wikipedia.org/wiki/Precision_and_recall).
* [Inter-annotator agreement](https://staff.fnwi.uva.nl/r.fernandezrovira/teaching/MoLProject2011/annotation-reliability.pdf)

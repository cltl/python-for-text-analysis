# The static folder

This is where all your images and other resources go.

# The templates folder

The templates folder is where Flask looks for its templates.
Store all your `.html` files here, so your app will be able to use them.
